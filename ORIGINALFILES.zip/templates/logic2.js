var mysql = require('mysql');

var con = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  database: "where_are_your_stores"
});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM njstores", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });
});