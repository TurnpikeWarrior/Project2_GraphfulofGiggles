var dataSet = [
    
      {
        City: "Avenel",
        Density: 4313.4920634920645,
        HouseOfUnits: 5076,
        LandArea: 3.78,
        Latitude: 40.5827122,
        Longitude: -74.27075090000001,
        NEBoundLatitude: 40.6022501,
        NEBoundLongitude: -74.24418809999999,
        Population: 16305,
        SWBoundLatitude: 40.56778389999999,
        SWBoungLongitude: -74.294534,
        State: "NJ",
        TotalWages: 298913215.0,
        WaterArea: 0.02,
        Wealthy: 18332.610548911376,
        Zipcode: "07001",
        ZipcodeType: "Standard"
        },
        {
        City: "Bayonne",
        Density: 10792.979452054797,
        HouseOfUnits: 27802,
        LandArea: 5.84,
        Latitude: 40.658801000000004,
        Longitude: -74.1063776,
        NEBoundLatitude: 40.6971391,
        NEBoundLongitude: -74.0683179,
        Population: 63031,
        SWBoundLatitude: 40.642275899999994,
        SWBoungLongitude: -74.14696090000001,
        State: "NJ",
        TotalWages: 1233471703.0,
        WaterArea: 0.81,
        Wealthy: 19569.286589138683,
        Zipcode: "07002",
        ZipcodeType: "Standard"
        },
        {
        City: "Bloomfield",
        Density: 8943.667296786389,
        HouseOfUnits: 19468,
        LandArea: 5.29,
        Latitude: 40.7989068,
        Longitude: -74.1885825,
        NEBoundLatitude: 40.848799,
        NEBoundLongitude: -74.162628,
        Population: 47312,
        SWBoundLatitude: 40.767838899999994,
        SWBoungLongitude: -74.21189,
        State: "NJ",
        TotalWages: 1127181370.0,
        WaterArea: 0.02,
        Wealthy: 23824.42868616841,
        Zipcode: "07003",
        ZipcodeType: "Standard"
        }
    ];
    
    console.log(dataSet);
    